<?php
class user_model extends CI_Model{
		
	

	function create($data)
		{
			if($this->db->insert('user', $data))
			{
				return TRUE;
			}
			return FALSE;
		}
		
		public function delete($id)
		{
			if ($this->db->delete("user", "id = ".$id)) 
				{
				return true;
				}
		}
		
		public function update($data,$id)
		{
			$this->db->set($data);
			$this->db->where("id", $id);
			$this->db->update("user", $data);
		}
		
		public function update_pass($data,$id)
		{
			$this->db->set($data);
			$this->db->where("id", $id);
			$this->db->update("user", $data);
		}

}
?>