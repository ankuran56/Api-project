<?php
class customer_model extends CI_Model{
	
	function upload_data($data)
		{
			if($this->db->insert('customer_table', $data))
			{
				return TRUE;
			}
			return FALSE;
		}
		
		public function delete($id)
		{
			if ($this->db->delete("customer_table", "id = ".$id)) 
				{
				return true;
				}
		}
}
?>