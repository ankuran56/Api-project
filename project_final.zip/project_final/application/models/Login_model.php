<?php
class Login_model extends CI_Model{
		
		function login()
			{
				$data = array(
					'user_id' => $this->input->post('user_id'),
					'utyp' => $this->input->post('user_id'),
					'logged_in' => TRUE
					);
					$this->session->set_userdata($data);
			}
			

	function logged_in()
		{
			if($this->session->userdata('logged_in') == TRUE)
				{
					return TRUE;
				}
				else
				{
					return FALSE;
				}
		}
}
?>