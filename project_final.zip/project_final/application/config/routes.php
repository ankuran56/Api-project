<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'Login';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

$route['home'] = "Main_cont";
$route['market'] = "MarketController";
$route['market/list'] = "MarketController/market_list";

$route['collector'] = "CollectorController";
$route['collector/list'] = "CollectorController/collector_list";

$route['customer'] = "CustomerController";
$route['customer/list'] = "CustomerController/customer_list";

$route['deposit'] = "DepositController";
$route['deposit/list'] = "DepositController/deposit_list";

$route['loan'] = "LoanController";
$route['loan/list'] = "LoanController/loan_list";

$route['collection/deposit'] = "CollectionController";
$route['collection/deposit_list'] = "CollectionController/collection_deposit_list";

$route['collection/loan'] = "CollectionController/collection_loan";
$route['collection/loan_list'] = "CollectionController/collection_loan_list";
