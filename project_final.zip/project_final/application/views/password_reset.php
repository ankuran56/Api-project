<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Online Admission Portal, Lakhimpur Girls College</title>
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="icon" href="user.png" type="image/x-icon">
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,700&subset=latin,cyrillic-ext" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" type="text/css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" />
    <link href="<?php echo base_url()?>home_assets/plugins/bootstrap/css/bootstrap.css" rel="stylesheet">
    <link href="<?php echo base_url()?>home_assets/plugins/node-waves/waves.css" rel="stylesheet" />
    <link href="<?php echo base_url()?>home_assets/plugins/animate-css/animate.css" rel="stylesheet" />
    <link href="<?php echo base_url()?>home_assets/plugins/waitme/waitMe.css" rel="stylesheet" />
    <link href="<?php echo base_url()?>home_assets/css/style.css" rel="stylesheet">
    <link href="<?php echo base_url()?>home_assets/css/custom.css" rel="stylesheet">
    <link href="<?php echo base_url()?>home_assets/css/themes/all-themes.css" rel="stylesheet" />
    <script>
	function chk(a,b){
	
		if(a!==b){ 
		alert("password does not match"); 
		 password.value='';
			cpassword.value='';
			password.focus;
		 }	
	}
	</script>
</head>
<body class="theme-blue view">
<div class="bg-overlay"></div>
    <!-- Page Loader -->
    <div class="page-loader-wrapper">
        <div class="loader">
            <div class="preloader">
                <div class="spinner-layer pl-blue">
                    <div class="circle-clipper left">
                        <div class="circle"></div>
                    </div>
                    <div class="circle-clipper right">
                        <div class="circle"></div>
                    </div>
                </div>
            </div>
            <p>Please wait...</p>
        </div>
    </div>
    <!-- #END# Page Loader -->
	<section style="padding-top:25px;">
		<div class="container">
			<div class="row">
				<?php include('header.php');?>
					<div class="col-lg-12">
                    <div class="card">
                        <div class="body">
						<div class="row">
							<div class="col-lg-4 col-lg-offset-4">
							<div class="card" style="margin-bottom:0;margin-top:15px;">
								<div class="header">
									<h2>
										Reset Password
									</h2>
								</div>
								<div class="body">
										<form id="sign_in" method="POST" action="<?php echo base_url()?>index.php/candidate/send_pass">
											<div class="msg col-teal font-12">
												Enter your email & mobile phone number that you used to register. We'll send you a code to reset your password.
											</div>
											<div class="input-group m-t-10" style="margin-bottom:10px;">
												<span class="input-group-addon">
													<i class="fa fa-sort-numeric-asc"></i>
												</span>
												<div class="form-line">
													<input type="text" class="form-control" name="email" placeholder="Email" required="" autofocus="" aria-invalid="true" aria-required="true">
												</div>
											</div>
											<div class="input-group">
												<span class="input-group-addon">
													<i class="material-icons">phone_android</i>
												</span>
												<div class="form-line">
													<input type="text" class="form-control" name="mobile" placeholder="Mobile Phone Number" required="" aria-invalid="true" aria-required="true">
												</div>
											</div>

											<button class="btn btn-block bg-blue waves-effect" type="submit">RESET MY PASSWORD</button>

											<div class="row m-t-20 m-b--5 align-center">
												<a href="index.html">Sign In!</a>
											</div>
										</form>
								</div>
							</div>
							</div>
                        </div>
                        </div>
                    </div>
                    </div>
            
				
			</div>
        </div>
	</section>

    <!-- SCRIPTS -->
    <script src="<?php echo base_url()?>home_assets/plugins/jquery/jquery.min.js"></script>
    <script src="<?php echo base_url()?>home_assets/plugins/bootstrap/js/bootstrap.js"></script>
    <script src="<?php echo base_url()?>home_assets/plugins/jquery-slimscroll/jquery.slimscroll.js"></script>
    <script src="<?php echo base_url()?>home_assets/plugins/node-waves/waves.js"></script>
    <script src="<?php echo base_url()?>home_assets/js/admin.js"></script>
    <script src="<?php echo base_url()?>home_assets/js/pages/ui/tooltips-popovers.js"></script>
</body>
</html>