
            <!-- START PAGE SIDEBAR -->
            <?php include('sidebar.php')?>
            <!-- END PAGE SIDEBAR -->
            
            <!-- PAGE CONTENT -->
            <div class="page-content">
                
                <!-- START X-NAVIGATION VERTICAL -->
                <?php include('topbar.php')?>
                <!-- END X-NAVIGATION VERTICAL -->                     
                
                <!-- START BREADCRUMB -->
                <ul class="breadcrumb">
					<li><a href="<?php echo site_url('Navigation_cont/load_dashboard')?>">Dashboard</a></li>
                </ul>
                <!-- END BREADCRUMB -->
                
                <!-- PAGE CONTENT WRAPPER -->
                <div class="page-content-wrap">
                    <div class="row" style="padding: 2px 15px;">
<div class="col-md-3">
<?php
 $datex=date('Y-m-d');
?>
    <div class="widget widget-primary widget-item-icon">
        <div class="widget-item-left">
            <span class="fa fa-users"></span>
        </div>                             
        <div class="widget-data">
            <div class="widget-subtitle">Category Items</div>
            <!-- <div class="widget-int num-count"><?php //echo get_amount('amount','collection_details',"where collection_type='DEPOSIT' and date='$datex'");?></div>
         -->
         <div class="widget-int num-count">00</div>
         </div>    
    </div>                         
</div>
<div class="col-md-3">
    <div class="widget widget-primary widget-item-icon">
        <div class="widget-item-left">
            <span class="fa fa-users"></span>
        </div>                             
        <div class="widget-data">
            <div class="widget-subtitle">Sub Category Items</div>
            <!-- <div class="widget-int num-count"><?php //echo get_amount('amount','collection_details',"where collection_type='LOAN' and date='$datex'");?></div>
         -->
         <div class="widget-int num-count">00</div>
         </div>    
    </div>                         
</div>
<!-- <div class="col-md-3">
    <div class="widget widget-primary widget-item-icon">
        <div class="widget-item-left">
            <span class="fa fa-users"></span>
        </div>                             
        <div class="widget-data">
            <div class="widget-subtitle">Deposit Collection</div>
            <div class="widget-int num-count"><?php //echo get_amount('amount','collection_details',"where collection_type='DEPOSIT'");?></div>
        </div>    
    </div>                         
</div>
<div class="col-md-3">
    <div class="widget widget-primary widget-item-icon">
        <div class="widget-item-left">
            <span class="fa fa-users"></span>
        </div>                             
        <div class="widget-data">
            <div class="widget-subtitle">Loan Collection</div>
            <div class="widget-int num-count"><?php //echo get_amount('amount','collection_details',"where collection_type='LOAN'");?></div>
        </div>    
    </div>                         
</div>
 -->						
</div>
					<!-- 
                    <div class="row" style="padding: 2px 15px;">	
                        <div class="col-md-2">
							<a href="#">
                            <div class="widget widget-info mt-25 widget-item-icon" style="min-height:70px">
                                <div class="widget-item-left">
                                    <span class="fa fa-users" style="font-size:30px; margin:5px; padding:5px;"></span>
                                </div>                             
                                <div class="widget-data">
                                    <div class="widget-int num-count" style="text-align:center">0</div>
                                    <div class="widget-subtitle" style="text-align:center">Doctor</div>
                                </div>    
							</div>
							</a>
                        </div>
                        
                        <div class="col-md-2">
							<a href="#">
                            <div class="widget widget-info mt-25 widget-item-icon" style="min-height:70px">
                                <div class="widget-item-left">
                                    <span class="fa fa-users" style="font-size:30px; margin:5px; padding:5px;"></span>
                                </div>                             
                                <div class="widget-data">
                                    <div class="widget-int num-count" style="text-align:center">0</div>
                                    <div class="widget-subtitle" style="text-align:center">Pathologist</div>
                                </div>    
							</div>
							</a>
                        </div>
                        
                        <div class="col-md-2">
							<a href="#">
                            <div class="widget widget-info mt-25 widget-item-icon" style="min-height:70px">
                                <div class="widget-item-left">
                                    <span class="fa fa-users" style="font-size:30px; margin:5px; padding:5px;"></span>
                                </div>                             
                                <div class="widget-data">
                                    <div class="widget-int num-count" style="text-align:center">0</div>
                                    <div class="widget-subtitle" style="text-align:center">Radiologist</div>
                                </div>    
							</div>
							</a>
                        </div>
                        
                        <div class="col-md-2">
							<a href="#">
                            <div class="widget widget-info mt-25 widget-item-icon" style="min-height:70px">
                                <div class="widget-item-left">
                                    <span class="fa fa-users" style="font-size:30px; margin:5px; padding:5px;"></span>
                                </div>                             
                                <div class="widget-data">
                                    <div class="widget-int num-count" style="text-align:center">0</div>
                                    <div class="widget-subtitle" style="text-align:center">Receptionist</div>
                                </div>    
							</div>
							</a>
                        </div>
                        
                        <div class="col-md-2">
							<a href="#">
                            <div class="widget widget-info mt-25 widget-item-icon" style="min-height:70px">
                                <div class="widget-item-left">
                                    <span class="fa fa-users" style="font-size:30px; margin:5px; padding:5px;"></span>
                                </div>                             
                                <div class="widget-data">
                                    <div class="widget-int num-count" style="text-align:center">0</div>
                                    <div class="widget-subtitle" style="text-align:center">Pharmacist</div>
                                </div>    
							</div>
							</a>
                        </div>
                        
                        <div class="col-md-2">
							<a href="#">
                            <div class="widget widget-info mt-25 widget-item-icon" style="min-height:70px">
                                <div class="widget-item-left">
                                    <span class="fa fa-users" style="font-size:30px; margin:5px; padding:5px;"></span>
                                </div>                             
                                <div class="widget-data">
                                    <div class="widget-int num-count" style="text-align:center">0</div>
                                    <div class="widget-subtitle" style="text-align:center">Accounts</div>
                                </div>    
							</div>
							</a>
                        </div>
						
                    </div> -->
                    
                    
                   <?php include('footer.php'); ?>
        