<?php
	$this->load->helper('html_helper');
	$this->load->helper('form');
	$this->load->helper('url');
	$uid= $this->session->userdata('user_id');
	$logged_in= $this->session->userdata('logged_in');
	if($uid==NULL or $logged_in==FALSE)
	{
		redirect('Navigation_cont/load_logout', 'refresh');
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>User Entry</title>            
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="icon" href="favicon.ico" type="image/x-icon" />    
        <?php echo link_tag(base_url().'assets/css/theme-default.css'); ?>
</head>
<script>
function panel_refresh(panel,action,callback){        
    if(!panel.hasClass("panel-refreshing")){
        panel.append('<div class="panel-refresh-layer"><img src="<?php echo base_url()?>assets/img/loaders/default.gif"/></div>');
        panel.find(".panel-refresh-layer").width(panel.width()).height(panel.height());
        panel.addClass("panel-refreshing");
        
        if(action && action === "shown" && typeof callback === "function") 
            callback();
    }else{
        panel.find(".panel-refresh-layer").remove();
        panel.removeClass("panel-refreshing");
        
        if(action && action === "hidden" && typeof callback === "function") 
            callback();        
    }       
    onload();
}
</script>
	<body>
        <!-- START PAGE CONTAINER -->
        <div class="page-container page-navigation-top-fixed">
            <!-- START PAGE SIDEBAR -->
            <?php include('sidebar.php')?>
            <!-- END PAGE SIDEBAR -->
            
            <!-- PAGE CONTENT -->
            <div class="page-content">
                
                <!-- START X-NAVIGATION VERTICAL -->
                <?php include('topbar.php')?>
                <!-- END X-NAVIGATION VERTICAL -->                     
                
                <!-- START BREADCRUMB -->
                <ul class="breadcrumb">
                    <li><a href="<?php echo site_url('Navigation_cont/load_dashboard')?>">Home</a></li>
                    <li><a href="#">User</a></li>
                    <li class="active">New Entry</li>
                </ul>
                <!-- END BREADCRUMB -->
                
                <!-- PAGE CONTENT WRAPPER -->
                <div class="page-content-wrap">
                
                    <div class="row">
                        <div class="col-md-12">
                            
                            
                            <div class="panel panel-default" style="margin-bottom:0px;">
                                <div class="panel-heading">
                                    <h3 class="panel-title"><strong>New User Entry</strong></h3>
                                </div>
                                <?php if (isset($succ)) {?>
                         		<div class="alert alert-success alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
								<?php echo $succ;?>                           
                            </div>
                             <?php } 
							 if(isset($wrong)){?>
                            <div class="alert alert-danger alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                <?php echo $wrong;?>
                            </div>
                            <?php }?>
                                <div class="panel-body">
								<!-- Personal Details -->
                                	<?php echo form_open('mus/new')?>
                                    	<div class="col-md-4">
											<div class="form-group">
												<label class="control-label" for="stream">User Name/ID*</label>
												<input class="form-control" placeholder="Enter Name" name="user_name" id="user_name" tabindex="1" required/>

                                                <span style="color:#EB090D; font-weight:bold;font-style:italic;"><?php echo form_error('user_name');?></span>
											</div>
										</div>
                                        <div class="col-md-4">
											<div class="form-group">
												<label class="control-label" for="formno">Password*</label>
												<input class="form-control" placeholder="Enter Password" name="password" id="password" tabindex="2" required/>

                                                <span style="color:#EB090D; font-weight:bold;font-style:italic;"><?php echo form_error('password'); ?></span>
											</div>
										</div>
                                        
                                        <div class="col-md-4">
											<div class="form-group">
												<label class="control-label" for="caste">Role/Type</label>
												<select id="user_type" name="user_type" required class="form-control">
													<option value="" style="display:none" selected>Select Type</option>
													<option value="Admin">Admin</option>
													<option value="Office Staff">Office Staff</option>
                                                    <option value="Teacher">Teacher</option>
                                                    <option value="Accounts">Accounts</option>
                                                    <option value="Student Welfare">Student Welfare</option>
                                                    <option value="Computer Assistent">Computer Assistent</option>
												</select>
                                                <span style="color:#EB090D; font-weight:bold;font-style:italic;"><?php echo form_error('user_type'); ?></span>
											</div>
										</div>
                                        
                                        
                                        
                                        
                                        <div class="col-md-3"><br>
                                        	<input type="reset" class="btn btn-default" value="Clear Form" />
                                            <input type="submit" value="Save Details" class="btn btn-primary pull-right" />
										</div>
                                  	<?php echo form_close(); ?>
                                </div>
                               
                            </div>  
                    		<div class="panel panel-default" style="margin-bottom:30px;">
                                <div class="panel-heading">
                                    <div class="pull-right">
                                        <button class="btn btn-danger toggle" data-toggle="exportTable"><i class="fa fa-bars"></i> Export Data</button>
                                    </div>
                                    <ul class="panel-controls">
                                        <li><a href="#" class="panel-fullscreen"><span class="fa fa-expand"></span></a></li>
                                        <li><a href="#" class="panel-refresh"><span class="fa fa-refresh"></span></a></li>&nbsp;&nbsp;&nbsp;  
                                    </ul>
                                </div>
                                <div class="panel-body" id="exportTable" style="display: none;">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <div class="list-group border-bottom">
                                                <a href="#" class="list-group-item" onClick ="$('#total-list').tableExport({type:'json',escape:'false'});"><img src='<?php echo base_url()?>assets/img/icons/json.png' width="24"/> JSON</a>
                                                <a href="#" class="list-group-item" onClick ="$('#total-list').tableExport({type:'json',escape:'false',ignoreColumn:'[2,3]'});"><img src='<?php echo base_url()?>assets/img/icons/json.png' width="24"/> JSON (ignoreColumn)</a>
                                                <a href="#" class="list-group-item" onClick ="$('#total-list').tableExport({type:'json',escape:'true'});"><img src='<?php echo base_url()?>assets/img/icons/json.png' width="24"/> JSON (with Escape)</a>
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="list-group border-bottom">
                                                <a href="#" class="list-group-item" onClick ="$('#total-list').tableExport({type:'xml',escape:'false'});"><img src='<?php echo base_url()?>assets/img/icons/xml.png' width="24"/> XML</a>
                                                <a href="#" class="list-group-item" onClick ="$('#total-list').tableExport({type:'sql'});"><img src='<?php echo base_url()?>assets/img/icons/sql.png' width="24"/> SQL</a>
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="list-group border-bottom">
                                                <a href="#" class="list-group-item" onClick ="$('#total-list').tableExport({type:'csv',escape:'false'});"><img src='<?php echo base_url()?>assets/img/icons/csv.png' width="24"/> CSV</a>
                                                <a href="#" class="list-group-item" onClick ="$('#total-list').tableExport({type:'txt',escape:'false'});"><img src='<?php echo base_url()?>assets/img/icons/txt.png' width="24"/> TXT</a>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="list-group border-bottom">
                                                <a href="#" class="list-group-item" onClick ="$('#total-list').tableExport({type:'excel',escape:'false'});"><img src='<?php echo base_url()?>assets/img/icons/xls.png' width="24"/> XLS</a>
                                                <a href="#" class="list-group-item" onClick ="$('#total-list').tableExport({type:'doc',escape:'false'});"><img src='<?php echo base_url()?>assets/img/icons/word.png' width="24"/> Word</a>
                                                <a href="#" class="list-group-item" onClick ="$('#total-list').tableExport({type:'powerpoint',escape:'false'});"><img src='<?php echo base_url()?>assets/img/icons/ppt.png' width="24"/> PowerPoint</a>
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="list-group border-bottom">
                                                <a href="#" class="list-group-item" onClick ="$('#total-list').tableExport({type:'png',escape:'false'});"><img src='<?php echo base_url()?>assets/img/icons/png.png' width="24"/> PNG</a>
                                                <a href="#" class="list-group-item" onClick ="$('#total-list').tableExport({type:'pdf',escape:'false'});"><img src='<?php echo base_url()?>assets/img/icons/pdf.png' width="24"/> PDF</a>
                                            </div>
                                        </div>
                                    </div>                               
                                </div>
                                <div class="panel-body panel-body-table" style="padding:5px;">
                                  	<div class="dataTable_wrapper">
                                        <table class="table table-striped table-bordered table-hover" id="total-list">
                                            <thead>
<tr>
                                            <th width="16%"><div align="left">User Name/ID</div></th>
                                            <th width="19%"><div align="left">User Type</div></th>
                                          <th width="12%"><div align="left">Password</div></th>
                                          <th width="8%"><div align="left">Edit</div></th>
                                          <th width="8%"><div align="left">Delete</div></th>
                                  </tr>                                            </thead>
                                           <tbody>
											<?php
                                            $query = $this->db->query("select * from user");
                                            foreach ($query->result() as $r)
                                            {				$sl=@$sl+1;
                                    		?>               
                                                    <tr class="odd gradeX">
                                            <td><div align="left"><?php echo $r->user_name;?></div></td>
                                            <td><div align="left"><?php echo $r->user_type;?></div></td>
                                            <td><div align="left"><a href="<?php echo base_url().'index.php/mus/pwd/'.$r->id?>" onClick="return confirm('Do you really want to Edit The Record?')">Change Password</a></div></td>
                                           <td> <div align="left"><a href="<?php echo base_url().'index.php/mus/upd/'.$r->id?>" onClick="return confirm('Do you really want to Edit The Record?')">Edit</a></div></td>
                                         <td> <div align="left"><a href="<?php echo base_url().'index.php/mus/del/'.$r->id?>" onClick="return confirm('Do you really want to Delete The Record?')">Delete</a></div></td>
                                                    </tr> 
                                                 
                                                <?php }?>   
                                          </tbody>
                                        </table>
                                	</div>
                                </div>
                            </div>                          
                        </div>
                    </div>
                    <footer>
						<div class="pull-right">
							For Support Call : <?php echo get_help_no();?>
						</div>
						<div class="clearfix"></div>
					</footer>                    
                </div>
                <!-- END PAGE CONTENT WRAPPER -->
            </div>            
            <!-- END PAGE CONTENT -->
        </div>
        <!-- END PAGE CONTAINER -->

        <!-- MESSAGE BOX-->
        <?php include('logout_mesg.php'); ?>
        <!-- END MESSAGE BOX-->
        <!-- success -->
        <div class="message-box message-box-success animated fadeIn" id="message-box-success">
            <div class="mb-container">
                <div class="mb-middle">
                    <div class="mb-title"><span class="fa fa-check"></span> Success</div>
                    <div class="mb-content">
                        <p>Data Successfully Saved In Your Database</p>                    
                    </div>
                        <button class="btn btn-default btn-lg pull-right mb-control-close">Close</button>
                    </div>
                </div>
            </div>
        </div>
        <!-- end success -->
        <!-- START PRELOADS -->
        <audio id="audio-alert" src="<?php echo base_url()?>assets/audio/alert.mp3" preload="auto"></audio>
        <audio id="audio-fail" src="<?php echo base_url()?>assets/audio/fail.mp3" preload="auto"></audio>
        <!-- END PRELOADS -->                 
    	<!-- START SCRIPTS -->
        <!-- START PLUGINS -->
                <?php echo script_tag(base_url().'assets/js/plugins/jquery/jquery.min.js'); ?>
                <?php echo script_tag(base_url().'assets/js/plugins/jquery/jquery-ui.min.js'); ?>
                <?php echo script_tag(base_url().'assets/js/plugins/bootstrap/bootstrap.min.js'); ?>
        <!-- END PLUGINS -->
        <!-- THIS PAGE PLUGINS -->
                <?php echo script_tag(base_url().'assets/js/plugins/icheck/icheck.min.js'); ?>
                <?php echo script_tag(base_url().'assets/js/plugins/mcustomscrollbar/jquery.mCustomScrollbar.min.js'); ?>
                <?php echo script_tag(base_url().'assets/js/plugins/bootstrap/bootstrap-datepicker.js'); ?>                
				<?php echo script_tag(base_url().'assets/js/plugins/bootstrap/bootstrap-file-input.js'); ?>
                <?php echo script_tag(base_url().'assets/js/plugins/bootstrap/bootstrap-select.js'); ?>
                <?php echo script_tag(base_url().'assets/js/plugins/tagsinput/jquery.tagsinput.min.js'); ?> 
                <?php echo script_tag(base_url().'assets/js/plugins/datatables/jquery.dataTables.min.js'); ?>
                <?php echo script_tag(base_url().'assets/js/plugins/tableexport/tableExport.js'); ?>
                <?php echo script_tag(base_url().'assets/js/plugins/tableexport/jquery.base64.js'); ?>
                <?php echo script_tag(base_url().'assets/js/plugins/tableexport/html2canvas.js'); ?>
                <?php echo script_tag(base_url().'assets/js/plugins/tableexport/jspdf/libs/sprintf.js'); ?>
                <?php echo script_tag(base_url().'assets/js/plugins/tableexport/jspdf/jspdf.js'); ?>
                <?php echo script_tag(base_url().'assets/js/plugins/tableexport/jspdf/libs/base64.js'); ?>        
        <!-- END THIS PAGE PLUGINS -->       
        <!-- START TEMPLATE -->        
				<?php echo script_tag(base_url().'assets/js/plugins.js'); ?>
                <?php echo script_tag(base_url().'assets/js/actions.js'); ?>
            
        <!-- END TEMPLATE -->
         <script>
			$(document).ready(function() {
				$('#total-list').DataTable({
						responsive: true
				});
			});
			$(document).ready(function() {
			$("#seat_no").keydown(function (e) {
				// Allow: backspace, delete, tab, escape, enter and .
				if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
					 // Allow: Ctrl+A, Command+A
					(e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) || 
					 // Allow: home, end, left, right, down, up
					(e.keyCode >= 35 && e.keyCode <= 40)) {
						 // let it happen, don't do anything
						 return;
				}
				// Ensure that it is a number and stop the keypress
				if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
					e.preventDefault();
				}
			});
		});
		</script>
    <!-- END SCRIPTS -->
    </body>
</html>