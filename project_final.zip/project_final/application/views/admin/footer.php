<footer>
<div class="pull-right">
For Support Call : (+91) 9706954576
</div>
<div class="clearfix"></div>
</footer>                    
</div>
                <!-- END PAGE CONTENT WRAPPER -->
            </div>            
            <!-- END PAGE CONTENT -->
        </div>
        <!-- END PAGE CONTAINER -->

        <!-- MESSAGE BOX-->
        <?php include('logout_mesg.php'); ?>
        <!-- END MESSAGE BOX-->
        <!-- success -->
        <div class="message-box message-box-success animated fadeIn" id="message-box-success">
            <div class="mb-container">
                <div class="mb-middle">
                    <div class="mb-title"><span class="fa fa-check"></span> Success</div>
                    <div class="mb-content">
                        <p>Data Successfully Saved In Your Database</p>                    
                    </div>
                        <button class="btn btn-default btn-lg pull-right mb-control-close">Close</button>
                    </div>
                </div>
            </div>
        </div>
        <!-- end success -->
        <!-- START PRELOADS -->
        <audio id="audio-alert" src="<?php echo base_url()?>assets/audio/alert.mp3" preload="auto"></audio>
        <audio id="audio-fail" src="<?php echo base_url()?>assets/audio/fail.mp3" preload="auto"></audio>
        <!-- END PRELOADS -->                 
        <!-- START SCRIPTS -->
        <!-- START PLUGINS -->
                <?php echo script_tag(base_url().'assets/js/plugins/jquery/jquery.min.js'); ?>
                <?php echo script_tag(base_url().'assets/js/plugins/jquery/jquery-ui.min.js'); ?>
                <?php echo script_tag(base_url().'assets/js/plugins/bootstrap/bootstrap.min.js'); ?>
        <!-- END PLUGINS -->
        <!-- THIS PAGE PLUGINS -->
                <?php echo script_tag(base_url().'assets/js/plugins/icheck/icheck.min.js'); ?>
                <?php echo script_tag(base_url().'assets/js/plugins/mcustomscrollbar/jquery.mCustomScrollbar.min.js'); ?>
                <?php echo script_tag(base_url().'assets/js/plugins/bootstrap/bootstrap-datepicker.js'); ?>                
                <?php echo script_tag(base_url().'assets/js/plugins/bootstrap/bootstrap-file-input.js'); ?>
                <?php echo script_tag(base_url().'assets/js/plugins/bootstrap/bootstrap-select.js'); ?>
                <?php echo script_tag(base_url().'assets/js/plugins/tagsinput/jquery.tagsinput.min.js'); ?> 
                <?php echo script_tag(base_url().'assets/js/plugins/datatables/jquery.dataTables.min.js'); ?>
                <?php echo script_tag(base_url().'assets/js/plugins/tableexport/tableExport.js'); ?>
                <?php echo script_tag(base_url().'assets/js/plugins/tableexport/jquery.base64.js'); ?>
                <?php echo script_tag(base_url().'assets/js/plugins/tableexport/html2canvas.js'); ?>
                <?php echo script_tag(base_url().'assets/js/plugins/tableexport/jspdf/libs/sprintf.js'); ?>
                <?php echo script_tag(base_url().'assets/js/plugins/tableexport/jspdf/jspdf.js'); ?>
                <?php echo script_tag(base_url().'assets/js/plugins/tableexport/jspdf/libs/base64.js'); ?>        
        <!-- END THIS PAGE PLUGINS -->       
        <!-- START TEMPLATE -->        
                <?php echo script_tag(base_url().'assets/js/plugins.js'); ?>
                <?php echo script_tag(base_url().'assets/js/actions.js'); ?>
            
<script>
      $(document).ready(function() {
        $('#total-list').DataTable({
            "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]]
        });
      });      
</script>
<?php echo script_tag(base_url().'assets/js/plugins/tableexport/tableExport.js'); ?>
<?php echo script_tag(base_url().'assets/js/plugins/tableexport/jquery.base64.js'); ?>
<?php echo script_tag(base_url().'assets/js/plugins/tableexport/jspdf/libs/base64.js'); ?>   

        <!-- END TEMPLATE -->
          </body>
</html>