<?php
    $this->load->helper('html_helper');
    $this->load->helper('form');
    $this->load->helper('url');

	$uid= $this->session->userdata('user_id');
     $user_id_only= $this->session->userdata('uidis');
    
    $logged_in= $this->session->userdata('logged_in');
    if($uid==NULL or $logged_in==FALSE)
    {
        redirect('Navigation_cont/load_logout', 'refresh');
    }
 $add= $this->session->userdata('utype');
    
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>project final sem</title>            
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="icon" href="favicon.ico" type="image/x-icon" />    
    <?php echo link_tag(base_url().'assets/css/theme-default.css'); ?>
    <style>
        .box {
            padding:25px;
            font-size:20px;
            text-align:center;
        }
        .box a {
            color:#fff;
            text-decoration:none;
        }
        .mt-25 {
            margin-top:25px;
        }
        .widget a {
            font-size:20px;
            color:#ffffff;
            text-decoration:none;
        }
    </style>
</head>
    <body>
        <!-- START PAGE CONTAINER -->
        <div class="page-container page-navigation-top-fixed">

<div class="page-sidebar page-sidebar-fixed scroll">
    <!-- START X-NAVIGATION -->
    <ul class="x-navigation">
        <li class="xn-logo">
            <a href="<?php echo site_url('Navigation_cont/load_dashboard')?>">ADMIN</a>
            <a href="#" class="x-navigation-control"></a>
        </li>
        <li class="xn-profile">
            <div class="profile">
                            <div class="profile-image">
                                <img src="<?php echo base_url()?>assets/logo1.jpg">
                            </div>
                <div class="profile-data">
                    <div class="profile-data-name"><?php echo $add;?> PANEL</div>
                    <div class="profile-data-title">Project </div>
                </div>
            </div>                                                                        
        </li>
        <li>
            <a href="<?php echo site_url('Navigation_cont/load_dashboard')?>"><span class="fa fa-desktop"></span> <span class="xn-text">Dashboard</span></a>                        
        </li>
       
        
        
        <li class="xn-openable">
            <a href="#"><span class="fa fa-cogs"></span> <span class="xn-text">Category Master</span></a>
            <ul>
               <li><a href="<?php echo site_url('collector')?>"><span class="fa fa-refresh"></span>Category List</a></li>
               <li><a href="<?php echo site_url('collector/list')?>"><span class="fa fa-refresh"></span>Sub Category List</a></li>
               
            </ul>
        </li>
        
         
    </ul>
    </li>
    <!-- END X-NAVIGATION -->
    
</div>
