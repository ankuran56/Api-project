<ul class="x-navigation x-navigation-horizontal x-navigation-panel">
    <!-- SEARCH -->
    <li class="title">
        Controll Panel :: Admin
    </li>   
    <!-- END SEARCH -->
    <!-- SIGN OUT -->
    <li class="xn-icon-button pull-right">
        <a href="#" class="mb-control" data-box="#mb-signout"><span class="fa fa-sign-out"></span></a>                        
    </li> 
    <!-- END SIGN OUT -->
</ul>