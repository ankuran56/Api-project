<?php
$this->load->helper('html_helper');
	$this->load->helper('form');
	$this->load->helper('url');
?>
<!DOCTYPE html>
<html lang="en" class="body-full-height">
    <head>        
        <title>Login</title>            
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="favicon.ico" type="/image/x-icon" />
        <?php echo link_tag(base_url().'assets/css/theme-default.css'); ?>
<style>
.profile-img-card {
    width: 100px;
    height: 100px;
	border-radius:3px;
    margin: 0 auto 10px;
    display: block;
}
</style>
    </head>
    <body>
        
        <div class="login-container">
        
            <div class="login-box animated fadeInDown">
                <div class="login-body">
                    <div class="login-title">
					<img class="profile-img-card" src="<?php echo base_url()?>assets/logo1.jpg" class="img-responsive" /></div>
					
                    <?php echo form_open('Login/chk_login',array('class'=>'form-horizontal'))?>
                    <div class="form-group">
                        <div class="col-md-12">
                            <input type="text" class="form-control" placeholder="Username" name="user_id" id="user_id"/>
                            <label style="color:red;"><?php echo form_error('user_id'); ?></label>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-12">
                            <input type="password" class="form-control" id="password" name="password" placeholder="Password"/>
                            <label style="color:red;"><?php echo form_error('password'); ?></label>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-12">
                            <button class="btn btn-info btn-lg btn-block">Log In</button>
                        </div>
                    </div>
				<?php echo form_close(); ?>
                </div>
            </div>
            
        </div>
        
    </body>
</html>