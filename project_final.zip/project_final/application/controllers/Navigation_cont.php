<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Navigation_cont extends CI_Controller {

function __construct() {
parent::__construct();
$this->load->library(array('form_validation', 'session'));
$this->load->helper(array('url', 'form'));
$this->load->helper('security');
$this->load->helper('security');
$this->load->database();
$this->load->library('upload');
}

function load_dashboard()
			{
				$this->load->view('admin/index');
			}
function load_logout()
			{
				$this->session->sess_destroy();
				$this->load->view('login');
			}	

}