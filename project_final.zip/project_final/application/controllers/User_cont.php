<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class user_cont extends CI_Controller {

function __construct() {
parent::__construct();
$this->load->library(array('form_validation', 'session'));
$this->load->helper(array('url', 'form'));
$this->load->model('user_model');
$this->load->helper('security');
$this->load->database();
}


			public function file_load()
			{
				$query = $this->db->get("user");
				$data['records'] = $query->result();
				$this->load->view('erp/user_entry',$data);
			}
			
				
			public function add_data()
			{
			$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
			$this->form_validation->set_rules('user_name', 'User Name', 'xss_clean|required|min_length[5]|max_length[20]|callback_user_exist');
			$this->form_validation->set_rules('user_type', 'User Type', 'xss_clean|required|min_length[3]');
			$this->form_validation->set_rules('password', 'Password', 'xss_clean|required|min_length[5]|max_length[15]');
			
					if($this->form_validation->run() == FALSE)
						{
								$this->load->view('erp/user_entry');
								
						}
						else
						{
										$password= $this->input->post('password');
										$password=md5($password);
						$data = array(
									'user_name' => $this->input->post('user_name'),
									'password' => $password,
									'user_type' => $this->input->post('user_type'),
									);

							if($this->user_model->create($data) === TRUE)
							{
								$data['succ'] = "Record Successfully Created";
								$this->load->view('erp/user_entry', $data);

							}
							else
							{
								$data['wrong'] ="Unsuccessfull Attempt";
								$this->load->view('erp/user_entry', $data);
							}
						}
			}
			
			
			function user_exist($name)
			{
				$query = $this->db->get_where('user', array('user_name'=>$name));
					if($query->num_rows() > 0)
						{
							$this->form_validation->set_message('user_exist', 'User Exist, please try another');
							return FALSE;
							}
						$query->free_result();
						return TRUE;
			}
			
			
			function change_pass()
			{
				$id=$this->uri->segment('3');
				$query = $this->db->get_where("user",array("id"=>$id));
				$data['records'] = $query->result();
				$this->load->view('erp/pass_change',$data);
			}
			
			
			public function update_file()
			{
			$id=$this->uri->segment('3');
			$query = $this->db->get_where("user",array("id"=>$id));
			$data['records'] = $query->result();
			$this->load->view('erp/user_edit',$data);
			}
			
			public function delete_file()
			{
			$id=$this->uri->segment('3');
				$this->user_model->delete($id);
				$query = $this->db->get("user");
				$data['records'] = $query->result();
				$this->load->view('erp/user_entry',$data);
			}


			public function save_file_edit()
			{
			
					
								$data = array(
									'user_name'=> $this->input->post('user_name'),
									'user_type' => $this->input->post('user_type'),
											);
											
							$id=$this->input->post('id');
							$this->user_model->update($data,$id);
							$query = $this->db->get("user");
							$data['records'] = $query->result();
							$this->load->view('erp/user_entry',$data);
						
			}
			
			public function save_pass_edit()
			{
			
			$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
			$this->form_validation->set_rules('op', 'Old Password', 'xss_clean|required|min_length[5]|max_length[15]|callback_chk_op');
			$this->form_validation->set_rules('np', 'New Password', 'xss_clean|required|min_length[6]|max_length[15]');
			$this->form_validation->set_rules('cp', 'Confirm Password', 'xss_clean|required|min_length[6]|max_length[15]|callback_chk_np');
					
					if($this->form_validation->run() == FALSE)
						{
							$id=$this->input->post('id');
							$query = $this->db->get_where("user",array("id"=>$id));
							$data['records'] = $query->result();
							$this->load->view('erp/pass_change',$data);
								
						}
						else
						{
										$np= $this->input->post('np');
										$np=md5($np);
						$data = array(
									'password'=> $np,
											);
											
							$id=$this->input->post('id');
							$this->user_model->update_pass($data,$id);
							$query = $this->db->get("user");
							$data['records'] = $query->result();
							$this->load->view('erp/user_entry',$data);
							

						}
			}
			
			
			function chk_op($op)
			{
				$id= $this->input->post('id');
				$op=md5($op);
				$query = $this->db->get_where('user', array('password'=>$op,'id'=>$id));
					if($query->num_rows() == 0)
						{
							$this->form_validation->set_message('chk_op', 'Invalid Password, Please Enter Correct Password');
							return FALSE;
							}
						$query->free_result();
						return TRUE;
			}
			
			function chk_np($cp)
			{
				$np= $this->input->post('np');
					if($np!==$cp)
						{
							$this->form_validation->set_message('chk_np', 'Password Not Match');
							return FALSE;
							}
						return TRUE;
			}
	
	

}
