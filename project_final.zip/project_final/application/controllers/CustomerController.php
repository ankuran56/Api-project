<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CustomerController extends CI_Controller {

function __construct() {
parent::__construct();
$this->load->library(array('form_validation', 'session'));
$this->load->helper(array('url', 'form'));
$this->load->helper('security');
$this->load->model('customer_model');
$this->load->database();
$this->load->library('upload');
}

function index()
{
	$this->load->view('admin/customer_entry');
}
function customer_list()
{
	$this->load->view('admin/customer_list');
}


function save_customer()
{
	$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
	$this->form_validation->set_rules('name', 'name', 'xss_clean|required|callback_collector_exist');
	if($this->form_validation->run() == FALSE)
	{ 
		$data['wrong']='Invalid Entry';			
		$this->load->view('admin/customer_entry',$data);
	}
	else
	{	 
		$name = $this->input->post('name');
		$father_name = $this->input->post('father_name');
		$spouse_name = $this->input->post('spouse_name');
		$date_of_birth = $this->input->post('date_of_birth');
		$bussiness_area = $this->input->post('bussiness_area');
		$present_address = $this->input->post('present_address');
		$permanent_address = $this->input->post('permanent_address');
		$nominee_name = $this->input->post('nominee_name');
		$relationship = $this->input->post('relationship');
		$pan_no = $this->input->post('pan_no');
		$adhaar_no = $this->input->post('adhaar_no');
		$other_id_no = $this->input->post('other_id_no');
		$id_details = $this->input->post('id_details');
		$issued_by = $this->input->post('issued_by');
		$customer_cif_no = $this->input->post('customer_cif_no');
		$phone = $this->input->post('phone');
		$phone_2 = $this->input->post('phone_2');
		$market = $this->input->post('market');
		$collector = $this->input->post('collector');
		
		$data = array(
		'name' => $name,
		'father_name' => $father_name,
		'spouse_name' => $spouse_name,
		'date_of_birth' => $date_of_birth,
		'bussiness_area' => $bussiness_area,
		'present_address' => $present_address,
		'permanent_address' => $permanent_address,
		'nominee_name' => $nominee_name,
		'relationship' => $relationship,
		'pan_no' => $pan_no,
		'adhaar_no' => $adhaar_no,
		'other_id_no' => $other_id_no,
		'id_details' => $id_details,
		'issued_by' => $issued_by,
		'customer_cif_no' => $customer_cif_no,
		'phone' => $phone,
		'phone_2' => $phone_2,
		'market' => $market,
		'collector' => $collector
		);				

		if($this->customer_model->upload_data($data) === TRUE)
		{
			$data['succ'] = "Record Successfully Created";
			$this->load->view('admin/customer_entry', $data);

		}
		else
		{
			$data['wrong'] ="Unsuccessfull Attempt";
			$this->load->view('admin/customer_entry', $data);
		}
	}
	
}


function collector_exist($name)
{
	$phone =$this->input->post("phone");	
	$query = $this->db->get_where('customer_table', array('name'=>$name,'phone'=>$phone));
	if($query->num_rows() > 0)
	{
		$this->form_validation->set_message('collector_exist', 'Market Exist, please try another');
		return FALSE;
	}
	$query->free_result();
	return TRUE;
}


//=================my work end==============//
}