<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

function __construct() {
parent::__construct();
$this->load->library(array('form_validation', 'session'));
$this->load->helper(array('url', 'form'));
$this->load->helper('security');
$this->load->model('Login_model');
$this->_salt = "123456789987654321";
$this->load->library('session'); 
$this->load->database();
}


		function index(){
		
							$this->load->view('login');
						}


		function chk_login()
			{
				
				$this->form_validation->set_rules('user_id', 'User ID','xss_clean|required|callback_user_id_check');
				
				$this->form_validation->set_rules('password', 'Password','xss_clean|required|min_length[4]|max_length[20]|callback_password_check');
				
				if($this->form_validation->run() == FALSE)
				{
					$this->load->view('login');
				}
				else
				{
					$this->Login_model->login();
					$user_id=$this->input->post('user_id');
					$this->load->view('admin/index');
				}
			}
		function user_id_check()
		{
			$user_id = $this->input->post('user_id');
				$this->db->where('user_name',$user_id);
				$query = $this->db->get('user_login');
				$result = $query->row_array();
				
				if($query->num_rows() == 1)
				{
				return TRUE;
				}
				
				if($query->num_rows() == 0)
				{
					$this->form_validation->set_message('user_id_check','Invalid User Name');
					return FALSE;

				}
			}
			
			
		function password_check()
			{
			
		$user_id = $this->input->post('user_id');
		$password = $this->input->post('password');
		$password = md5($password);

		
				$this->db->where('user_name',$user_id);
				$query = $this->db->get('user_login');
				$result = $query->row_array();
				$pass1=$result['password'];
				//$user_type=$result['user_type'];
				if($pass1!==$password)
				{
					$this->form_validation->set_message('password_check','Invalid Password');
					return FALSE;			
				}
				
				if($pass1==$password)
				{
				
				$email=$result['user_type'];
				$this->session->set_userdata('utype',$email);
				$uid=$result['id'];
				$this->session->set_userdata('uidis',$uid);
					return TRUE;
				}
				
			}

	
}