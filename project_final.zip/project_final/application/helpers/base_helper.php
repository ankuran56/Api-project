<?php  
if ( ! defined('BASEPATH')) exit('No direct script access allowed');


function get_name($field_name,$tabl_name,$condition)
{
	$val=0; 
    $CI =& get_instance();
	$qryx=$CI->db->query("select $field_name from $tabl_name $condition");
	$result = $qryx->row_array();
	$val=$result[$field_name];
	return $val;
}

function get_amount($field_name,$tabl_name,$condition)
{
	$val=0; 
    $CI =& get_instance();
	$qryx=$CI->db->query("select $field_name from $tabl_name $condition");
	$result=$qryx->result();
	foreach($result as $r)
	{    
	$val=$val+$r->amount;    
	}
	return $val;

}


